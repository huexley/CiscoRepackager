//
//  ModuleChoice.swift
//  CiscoRepackager
//
//  Created by Yannick Housseau
//  https://github.com/huexley
//
//  MIT License - See LICENSE file for details
//

import Foundation

/// Represents a selectable Cisco module from the Distribution file
struct ModuleChoice: Identifiable, Hashable {
    /// Identifier in the Distribution file (e.g., "choice_anyconnect_vpn")
    let id: String
    /// Display name shown to the user (e.g., "AnyConnect VPN")
    let title: String
    /// Whether this module is selected for inclusion in the final PKG
    var isSelected: Bool
    
    // MARK: - Hashable (based on ID only)
    
    func hash(into hasher: inout Hasher) {
        hasher.combine(id)
    }
    
    static func == (lhs: ModuleChoice, rhs: ModuleChoice) -> Bool {
        lhs.id == rhs.id
    }
}

/// Information extracted from the Cisco package
struct CiscoPackageInfo {
    let version: String
    let modules: [ModuleChoice]
}
