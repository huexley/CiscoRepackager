//
//  ContentView.swift
//  CiscoRepackager
//
//  Created by Yannick Housseau
//  https://github.com/huexley
//
//  MIT License - See LICENSE file for details
//

import SwiftUI
import UniformTypeIdentifiers

enum AppStep {
    case dropDMG
    case selectModules
    case addOrgInfo
}

struct ContentView: View {
    @StateObject private var dmgService = DMGService()
    @State private var isShowingFileImporter = false
    @State private var isShowingOrgInfoImporter = false
    @State private var isTargeted = false
    @State private var currentStep: AppStep = .dropDMG
    @State private var orgInfoURL: URL?
    @State private var isOrgInfoTargeted = false
    
    // Check if Umbrella is selected
    private var isUmbrellaSelected: Bool {
        dmgService.modules.contains { $0.id == "choice_secure_umbrella" && $0.isSelected }
    }
    
    var body: some View {
        VStack(spacing: 0) {
            // Fixed header
            headerView
                .padding()
            
            Divider()
            
            // Main content based on step
            Group {
                switch currentStep {
                case .dropDMG:
                    step1DropZone
                case .selectModules:
                    step2ModuleSelection
                case .addOrgInfo:
                    step3OrgInfo
                }
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
        }
        .frame(minWidth: 500, minHeight: 450)
        .fileImporter(
            isPresented: $isShowingFileImporter,
            allowedContentTypes: [UTType(filenameExtension: "dmg")!],
            allowsMultipleSelection: false
        ) { result in
            dmgService.handleFileImporterResult(result)
        }
        .fileImporter(
            isPresented: $isShowingOrgInfoImporter,
            allowedContentTypes: [UTType.json],
            allowsMultipleSelection: false
        ) { result in
            handleOrgInfoImport(result)
        }
        .onChange(of: dmgService.isPrepared) { _, isPrepared in
            if isPrepared {
                currentStep = .selectModules
            }
        }
    }
    
    // MARK: - Header
    
    private var headerView: some View {
        HStack {
            Image(systemName: "shippingbox.fill")
                .font(.largeTitle)
                .foregroundColor(.accentColor)
            
            VStack(alignment: .leading, spacing: 2) {
                Text("Cisco Secure Client")
                    .font(.title2)
                    .fontWeight(.bold)
                Text("Repackager for Jamf")
                    .font(.subheadline)
                    .foregroundColor(.secondary)
            }
            
            Spacer()
            
            // Step indicator
            if currentStep != .dropDMG {
                HStack(spacing: 4) {
                    stepDot(step: 1, current: currentStep != .dropDMG)
                    Rectangle().frame(width: 20, height: 2).foregroundColor(.secondary.opacity(0.3))
                    stepDot(step: 2, current: currentStep == .selectModules || currentStep == .addOrgInfo)
                    if isUmbrellaSelected || currentStep == .addOrgInfo {
                        Rectangle().frame(width: 20, height: 2).foregroundColor(.secondary.opacity(0.3))
                        stepDot(step: 3, current: currentStep == .addOrgInfo)
                    }
                }
                .padding(.horizontal)
            }
            
            if currentStep != .dropDMG {
                Button {
                    resetAll()
                } label: {
                    Label("Start Over", systemImage: "arrow.counterclockwise")
                }
                .buttonStyle(.borderless)
            }
            
            if dmgService.isBusy {
                ProgressView()
                    .scaleEffect(0.8)
                    .padding(.leading, 8)
            }
        }
    }
    
    private func stepDot(step: Int, current: Bool) -> some View {
        ZStack {
            Circle()
                .fill(current ? Color.accentColor : Color.secondary.opacity(0.3))
                .frame(width: 24, height: 24)
            Text("\(step)")
                .font(.caption)
                .fontWeight(.bold)
                .foregroundColor(current ? .white : .secondary)
        }
    }
    
    // MARK: - Step 1: Drop Zone
    
    private var step1DropZone: some View {
        VStack(spacing: 24) {
            Spacer()
            
            // Drop zone
            VStack(spacing: 16) {
                ZStack {
                    RoundedRectangle(cornerRadius: 16)
                        .strokeBorder(
                            isTargeted ? Color.accentColor : Color.gray.opacity(0.3),
                            style: StrokeStyle(lineWidth: 2, dash: [10])
                        )
                        .background(
                            RoundedRectangle(cornerRadius: 16)
                                .fill(isTargeted ? Color.accentColor.opacity(0.08) : Color.gray.opacity(0.03))
                        )
                    
                    VStack(spacing: 12) {
                        Image(systemName: "opticaldisc")
                            .font(.system(size: 48))
                            .foregroundColor(isTargeted ? .accentColor : .secondary)
                        
                        Text("Drop Cisco Secure Client DMG here")
                            .font(.headline)
                            .foregroundColor(.primary)
                        
                        Text("or click to browse")
                            .font(.subheadline)
                            .foregroundColor(.secondary)
                    }
                }
                .frame(height: 200)
                .contentShape(Rectangle())
                .onTapGesture {
                    isShowingFileImporter = true
                }
                .onDrop(of: [.fileURL], isTargeted: $isTargeted) { providers in
                    dmgService.handleDrop(providers: providers)
                }
                .animation(.easeInOut(duration: 0.2), value: isTargeted)
            }
            .padding(.horizontal, 40)
            
            // Info when DMG is selected
            if let dmgURL = dmgService.dmgURL {
                VStack(spacing: 12) {
                    HStack(spacing: 8) {
                        Image(systemName: "checkmark.circle.fill")
                            .foregroundColor(.green)
                        Text(dmgURL.lastPathComponent)
                            .fontWeight(.medium)
                        if let version = dmgService.version {
                            Text("v\(version)")
                                .foregroundColor(.secondary)
                                .padding(.horizontal, 8)
                                .padding(.vertical, 2)
                                .background(Color.secondary.opacity(0.15))
                                .clipShape(Capsule())
                        }
                    }
                    
                    Button {
                        Task { await dmgService.prepare() }
                    } label: {
                        HStack {
                            Image(systemName: "arrow.right.circle.fill")
                            Text("Continue")
                        }
                        .frame(minWidth: 120)
                    }
                    .buttonStyle(.borderedProminent)
                    .controlSize(.large)
                    .disabled(dmgService.isBusy)
                }
            }
            
            // Discreet log at the bottom
            if !dmgService.logText.isEmpty {
                logView
                    .frame(height: 80)
                    .padding(.horizontal)
            }
            
            Spacer()
        }
    }
    
    // MARK: - Step 2: Module Selection
    
    private var step2ModuleSelection: some View {
        VStack(spacing: 0) {
            // DMG info bar
            HStack {
                Image(systemName: "opticaldisc.fill")
                    .foregroundColor(.accentColor)
                if let dmgURL = dmgService.dmgURL {
                    Text(dmgURL.lastPathComponent)
                        .fontWeight(.medium)
                }
                if let version = dmgService.version {
                    Text("v\(version)")
                        .foregroundColor(.secondary)
                        .padding(.horizontal, 8)
                        .padding(.vertical, 2)
                        .background(Color.secondary.opacity(0.15))
                        .clipShape(Capsule())
                }
                Spacer()
                
                Button("Select All") {
                    for i in dmgService.modules.indices {
                        dmgService.modules[i].isSelected = true
                    }
                }
                .buttonStyle(.borderless)
                
                Button("None") {
                    for i in dmgService.modules.indices {
                        dmgService.modules[i].isSelected = false
                    }
                }
                .buttonStyle(.borderless)
            }
            .padding()
            .background(Color.gray.opacity(0.05))
            
            Divider()
            
            // Module list
            ScrollView {
                VStack(alignment: .leading, spacing: 0) {
                    ForEach($dmgService.modules) { $module in
                        ModuleRow(module: $module)
                        
                        if module.id != dmgService.modules.last?.id {
                            Divider()
                                .padding(.leading, 52)
                        }
                    }
                }
            }
            
            Divider()
            
            // Log
            logView
                .frame(height: 100)
            
            Divider()
            
            // Bottom bar with buttons
            HStack {
                if !dmgService.hasSelectedModules {
                    HStack(spacing: 4) {
                        Image(systemName: "exclamationmark.triangle.fill")
                            .foregroundColor(.orange)
                        Text("Select at least one module")
                            .foregroundColor(.secondary)
                    }
                }
                
                Spacer()
                
                // Show different button based on Umbrella selection
                if isUmbrellaSelected {
                    Button {
                        currentStep = .addOrgInfo
                    } label: {
                        HStack {
                            Image(systemName: "arrow.right.circle.fill")
                            Text("Continue")
                        }
                        .frame(minWidth: 140)
                    }
                    .buttonStyle(.borderedProminent)
                    .controlSize(.large)
                    .disabled(!dmgService.hasSelectedModules || dmgService.isBusy)
                } else {
                    Button {
                        Task { await dmgService.buildFinalPKG(orgInfoURL: nil) }
                    } label: {
                        HStack {
                            Image(systemName: "hammer.fill")
                            Text("Build PKG")
                        }
                        .frame(minWidth: 140)
                    }
                    .buttonStyle(.borderedProminent)
                    .tint(.green)
                    .controlSize(.large)
                    .disabled(!dmgService.hasSelectedModules || dmgService.isBusy)
                }
            }
            .padding()
        }
    }
    
    // MARK: - Step 3: OrgInfo.json
    
    private var step3OrgInfo: some View {
        VStack(spacing: 0) {
            // Info bar
            HStack {
                Image(systemName: "umbrella.fill")
                    .foregroundColor(.accentColor)
                Text("Umbrella Configuration")
                    .fontWeight(.medium)
                Spacer()
                Text("Optional")
                    .foregroundColor(.secondary)
                    .padding(.horizontal, 8)
                    .padding(.vertical, 2)
                    .background(Color.secondary.opacity(0.15))
                    .clipShape(Capsule())
            }
            .padding()
            .background(Color.gray.opacity(0.05))
            
            Divider()
            
            // Main content
            VStack(spacing: 24) {
                Spacer()
                
                // Drop zone for OrgInfo.json
                ZStack {
                    RoundedRectangle(cornerRadius: 16)
                        .strokeBorder(
                            isOrgInfoTargeted ? Color.accentColor : (orgInfoURL != nil ? Color.green : Color.gray.opacity(0.3)),
                            style: StrokeStyle(lineWidth: 2, dash: orgInfoURL == nil ? [10] : [])
                        )
                        .background(
                            RoundedRectangle(cornerRadius: 16)
                                .fill(isOrgInfoTargeted ? Color.accentColor.opacity(0.08) : (orgInfoURL != nil ? Color.green.opacity(0.05) : Color.gray.opacity(0.03)))
                        )
                    
                    VStack(spacing: 12) {
                        if let orgInfoURL = orgInfoURL {
                            Image(systemName: "checkmark.circle.fill")
                                .font(.system(size: 48))
                                .foregroundColor(.green)
                            Text(orgInfoURL.lastPathComponent)
                                .font(.headline)
                                .foregroundColor(.primary)
                            Button("Remove") {
                                self.orgInfoURL = nil
                            }
                            .buttonStyle(.borderless)
                            .foregroundColor(.red)
                        } else {
                            Image(systemName: "doc.badge.plus")
                                .font(.system(size: 48))
                                .foregroundColor(isOrgInfoTargeted ? .accentColor : .secondary)
                            Text("Drop OrgInfo.json here")
                                .font(.headline)
                                .foregroundColor(.primary)
                            Text("or click to browse")
                                .font(.subheadline)
                                .foregroundColor(.secondary)
                        }
                    }
                }
                .frame(height: 180)
                .padding(.horizontal, 40)
                .contentShape(Rectangle())
                .onTapGesture {
                    if orgInfoURL == nil {
                        isShowingOrgInfoImporter = true
                    }
                }
                .onDrop(of: [.fileURL], isTargeted: $isOrgInfoTargeted) { providers in
                    handleOrgInfoDrop(providers: providers)
                }
                .animation(.easeInOut(duration: 0.2), value: isOrgInfoTargeted)
                
                // Info text
                VStack(spacing: 8) {
                    Text("The OrgInfo.json file contains your organization's Umbrella configuration.")
                        .font(.subheadline)
                        .foregroundColor(.secondary)
                        .multilineTextAlignment(.center)
                    
                    Text("It will be installed to: /opt/cisco/secureclient/umbrella/")
                        .font(.caption)
                        .foregroundColor(.secondary)
                        .padding(.horizontal, 12)
                        .padding(.vertical, 6)
                        .background(Color.secondary.opacity(0.1))
                        .clipShape(RoundedRectangle(cornerRadius: 6))
                }
                .padding(.horizontal, 40)
                
                Spacer()
            }
            
            Divider()
            
            // Log
            logView
                .frame(height: 80)
            
            Divider()
            
            // Bottom bar
            HStack {
                Button {
                    currentStep = .selectModules
                } label: {
                    HStack {
                        Image(systemName: "arrow.left")
                        Text("Back")
                    }
                }
                .buttonStyle(.borderless)
                
                Spacer()
                
                Button {
                    Task { await dmgService.buildFinalPKG(orgInfoURL: nil) }
                } label: {
                    Text("Skip")
                }
                .buttonStyle(.bordered)
                .disabled(dmgService.isBusy)
                
                Button {
                    Task { await dmgService.buildFinalPKG(orgInfoURL: orgInfoURL) }
                } label: {
                    HStack {
                        Image(systemName: "hammer.fill")
                        Text("Build PKG")
                    }
                    .frame(minWidth: 140)
                }
                .buttonStyle(.borderedProminent)
                .tint(.green)
                .controlSize(.large)
                .disabled(dmgService.isBusy)
            }
            .padding()
        }
    }
    
    // MARK: - Log View
    
    private var logView: some View {
        ScrollViewReader { proxy in
            ScrollView {
                Text(dmgService.logText.isEmpty ? "Ready..." : dmgService.logText)
                    .font(.system(size: 11, design: .monospaced))
                    .foregroundColor(dmgService.logText.isEmpty ? .secondary : .primary)
                    .frame(maxWidth: .infinity, alignment: .topLeading)
                    .padding(8)
                    .id("logBottom")
            }
            .background(Color(NSColor.textBackgroundColor))
            .onChange(of: dmgService.logText) { _, _ in
                withAnimation {
                    proxy.scrollTo("logBottom", anchor: .bottom)
                }
            }
        }
    }
    
    // MARK: - Helpers
    
    private func resetAll() {
        dmgService.reset()
        currentStep = .dropDMG
        orgInfoURL = nil
    }
    
    private func handleOrgInfoImport(_ result: Result<[URL], Error>) {
        switch result {
        case .success(let urls):
            if let url = urls.first {
                orgInfoURL = url
            }
        case .failure(let error):
            dmgService.appendLogPublic("[ERROR] Failed to import OrgInfo.json: \(error.localizedDescription)")
        }
    }
    
    private func handleOrgInfoDrop(providers: [NSItemProvider]) -> Bool {
        guard let provider = providers.first else { return false }
        
        if provider.hasItemConformingToTypeIdentifier(UTType.fileURL.identifier) {
            provider.loadItem(forTypeIdentifier: UTType.fileURL.identifier, options: nil) { item, error in
                Task { @MainActor in
                    if let data = item as? Data,
                       let url = URL(dataRepresentation: data, relativeTo: nil),
                       url.lastPathComponent.lowercased() == "orginfo.json" {
                        self.orgInfoURL = url
                    }
                }
            }
            return true
        }
        return false
    }
}

// MARK: - Module Row

struct ModuleRow: View {
    @Binding var module: ModuleChoice
    
    var body: some View {
        HStack(spacing: 12) {
            Toggle("", isOn: $module.isSelected)
                .toggleStyle(.checkbox)
                .labelsHidden()
            
            moduleIcon
                .font(.title2)
                .foregroundColor(module.isSelected ? .accentColor : .secondary)
                .frame(width: 28)
            
            VStack(alignment: .leading, spacing: 2) {
                Text(module.title)
                    .fontWeight(.medium)
                    .foregroundColor(module.isSelected ? .primary : .secondary)
                
                Text(moduleDescription)
                    .font(.caption)
                    .foregroundColor(.secondary)
            }
            
            Spacer()
        }
        .padding(.horizontal)
        .padding(.vertical, 10)
        .contentShape(Rectangle())
        .onTapGesture {
            module.isSelected.toggle()
        }
    }
    
    private var moduleIcon: Image {
        let id = module.id.lowercased()
        if id.contains("vpn") {
            return Image(systemName: "lock.shield.fill")
        } else if id.contains("fireamp") || id.contains("amp") {
            return Image(systemName: "shield.checkered")
        } else if id.contains("dart") {
            return Image(systemName: "wrench.and.screwdriver.fill")
        } else if id.contains("posture") || id.contains("ise") {
            return Image(systemName: "checkmark.seal.fill")
        } else if id.contains("nvm") {
            return Image(systemName: "eye.fill")
        } else if id.contains("umbrella") {
            return Image(systemName: "umbrella.fill")
        } else if id.contains("duo") {
            return Image(systemName: "person.2.fill")
        } else if id.contains("zta") || id.contains("ztna") {
            return Image(systemName: "network.badge.shield.half.filled")
        } else if id.contains("thousandeyes") {
            return Image(systemName: "waveform.path.ecg")
        } else {
            return Image(systemName: "puzzlepiece.fill")
        }
    }
    
    private var moduleDescription: String {
        let id = module.id.lowercased()
        if id.contains("vpn") {
            return "Secure VPN client for remote access"
        } else if id.contains("fireamp") || id.contains("amp") {
            return "Advanced Malware Protection"
        } else if id.contains("dart") {
            return "Diagnostic and Reporting Tool"
        } else if id.contains("posture") || id.contains("ise") {
            return "Endpoint compliance assessment"
        } else if id.contains("nvm") {
            return "Network Visibility Module"
        } else if id.contains("umbrella") {
            return "DNS-layer security"
        } else if id.contains("duo") {
            return "Multi-factor authentication"
        } else if id.contains("zta") || id.contains("ztna") {
            return "Zero Trust Access"
        } else if id.contains("thousandeyes") {
            return "Network intelligence"
        } else {
            return "Cisco security module"
        }
    }
}

// MARK: - Preview

#Preview {
    ContentView()
}
