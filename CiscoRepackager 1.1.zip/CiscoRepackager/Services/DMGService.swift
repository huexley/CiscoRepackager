//
//  DMGService.swift
//  CiscoRepackager
//
//  Created by Yannick Housseau
//  https://github.com/huexley
//
//  MIT License - See LICENSE file for details
//

import Foundation
import AppKit
import UniformTypeIdentifiers
import Combine

// MARK: - Errors

enum DMGServiceError: Error, LocalizedError {
    case noDMGSelected
    case pkgNotFound
    case commandFailed(command: String, status: Int32, stderr: String)
    case userCancelled
    case noModulesSelected
    case preparationRequired
    case orgInfoCreationFailed
    
    var errorDescription: String? {
        switch self {
        case .noDMGSelected:
            return "No DMG file selected."
        case .pkgNotFound:
            return "Could not find \"Cisco Secure Client.pkg\" inside the mounted DMG."
        case .commandFailed(let command, let status, let stderr):
            return "Command failed (\(status)): \(command)\n\(stderr)"
        case .userCancelled:
            return "Operation cancelled by user."
        case .noModulesSelected:
            return "Please select at least one module to include."
        case .preparationRequired:
            return "Please prepare the DMG first."
        case .orgInfoCreationFailed:
            return "Failed to create OrgInfo package."
        }
    }
}

// MARK: - DMGService

@MainActor
final class DMGService: ObservableObject {
    
    // MARK: - Published Properties (for SwiftUI binding)
    
    @Published var dmgURL: URL?
    @Published var version: String?
    @Published var modules: [ModuleChoice] = []
    @Published var logText: String = ""
    @Published var isBusy: Bool = false
    
    // Internal state
    @Published private(set) var isPrepared: Bool = false
    
    // MARK: - Private Properties
    
    private var tempRoot: URL?
    private var expandedFolder: URL?
    private var distributionURL: URL?
    
    // MARK: - Computed Properties
    
    var hasSelectedModules: Bool {
        modules.contains { $0.isSelected }
    }
    
    var filteredDistributionURL: URL? {
        isPrepared ? distributionURL : nil
    }
    
    // MARK: - Public API
    
    /// Completely resets the service state
    func reset() {
        cleanup()
        dmgURL = nil
        version = nil
        modules = []
        logText = ""
        isBusy = false
        isPrepared = false
        tempRoot = nil
        expandedFolder = nil
        distributionURL = nil
    }
    
    /// Handles a DMG file drop
    func handleDrop(providers: [NSItemProvider]) -> Bool {
        guard let provider = providers.first else { return false }
        
        if provider.hasItemConformingToTypeIdentifier(UTType.fileURL.identifier) {
            provider.loadItem(forTypeIdentifier: UTType.fileURL.identifier, options: nil) { item, error in
                Task { @MainActor in
                    if let data = item as? Data,
                       let url = URL(dataRepresentation: data, relativeTo: nil),
                       url.pathExtension.lowercased() == "dmg" {
                        self.setDMG(url: url)
                    }
                }
            }
            return true
        }
        return false
    }
    
    /// Handles the file importer result
    func handleFileImporterResult(_ result: Result<[URL], Error>) {
        switch result {
        case .success(let urls):
            if let url = urls.first {
                setDMG(url: url)
            }
        case .failure(let error):
            appendLog("[ERROR] File selection error: \(error.localizedDescription)")
        }
    }
    
    /// Sets the DMG and detects version
    func setDMG(url: URL) {
        // Reset if changing DMG
        if dmgURL != url {
            modules = []
            isPrepared = false
            logText = ""
        }
        
        dmgURL = url
        version = detectVersion(from: url)
        appendLog("DMG selected: \(url.lastPathComponent)")
        if let v = version {
            appendLog("Version detected: \(v)")
        }
    }
    
    /// Prepares the DMG: mounts, expands, and parses modules
    func prepare() async {
        guard let dmgURL else {
            appendLog("[ERROR] No DMG selected")
            return
        }
        
        isBusy = true
        defer { isBusy = false }
        
        // Cleanup previous state if needed
        cleanup()
        
        do {
            let fileManager = FileManager.default
            
            // Create a unique temporary folder
            let tempRoot = fileManager.temporaryDirectory
                .appendingPathComponent("CiscoRepackager-\(UUID().uuidString)")
            try fileManager.createDirectory(at: tempRoot, withIntermediateDirectories: true)
            self.tempRoot = tempRoot
            
            let mountPoint = tempRoot.appendingPathComponent("mount")
            try fileManager.createDirectory(at: mountPoint, withIntermediateDirectories: true)
            
            // Mount the DMG
            appendLog("Mounting DMG...")
            try await runCommand("/usr/bin/hdiutil", arguments: [
                "attach", dmgURL.path,
                "-mountpoint", mountPoint.path,
                "-nobrowse",
                "-readonly",
                "-noverify"
            ])
            appendLog("DMG mounted at \(mountPoint.path)")
            
            // Look for the PKG
            let pkgURL = mountPoint.appendingPathComponent("Cisco Secure Client.pkg")
            guard fileManager.fileExists(atPath: pkgURL.path) else {
                throw DMGServiceError.pkgNotFound
            }
            appendLog("Found: Cisco Secure Client.pkg")
            
            // Expand the PKG
            let expandedFolder = tempRoot.appendingPathComponent("ExpandedPKG")
            appendLog("Expanding package...")
            try await runCommand("/usr/sbin/pkgutil", arguments: [
                "--expand", pkgURL.path,
                expandedFolder.path
            ])
            self.expandedFolder = expandedFolder
            appendLog("Package expanded")
            
            // Parse the Distribution file
            let distributionURL = expandedFolder.appendingPathComponent("Distribution")
            self.distributionURL = distributionURL
            
            appendLog("Parsing Distribution file...")
            let packageInfo = try PKGParser.parse(distributionURL: distributionURL)
            
            self.modules = packageInfo.modules
            if packageInfo.version != "Unknown" {
                self.version = packageInfo.version
            }
            
            appendLog("Found \(packageInfo.modules.count) modules:")
            for module in packageInfo.modules {
                let status = module.isSelected ? "[x]" : "[ ]"
                appendLog("   \(status) \(module.title)")
            }
            
            // Unmount the DMG (no longer needed)
            appendLog("Unmounting DMG...")
            try await runCommand("/usr/bin/hdiutil", arguments: [
                "detach", mountPoint.path,
                "-force"
            ])
            
            isPrepared = true
            appendLog("Preparation complete. Select modules and build your PKG.")
            
        } catch {
            appendLog("[ERROR] \(error.localizedDescription)")
            cleanup()
        }
    }
    
    /// Builds the final PKG with selected modules and optional OrgInfo.json
    func buildFinalPKG(orgInfoURL: URL?) async {
        guard isPrepared else {
            appendLog("[ERROR] Please prepare the DMG first")
            return
        }
        
        guard let expandedFolder, let distributionURL else {
            appendLog("[ERROR] Internal error: missing paths")
            return
        }
        
        guard hasSelectedModules else {
            appendLog("[ERROR] Please select at least one module")
            return
        }
        
        isBusy = true
        defer { isBusy = false }
        
        do {
            // Ask where to save
            let suggestedName = "CiscoSecureClient-\(version ?? "custom").pkg"
            guard let saveURL = await askUserForOutputURL(suggestedName: suggestedName) else {
                appendLog("Build cancelled")
                return
            }
            
            // Modify the Distribution file
            appendLog("Updating Distribution file...")
            let selectedModules = modules.filter { $0.isSelected }
            appendLog("   Including: \(selectedModules.map { $0.title }.joined(separator: ", "))")
            
            try PKGParser.writeFilteredDistribution(
                originalURL: distributionURL,
                destinationURL: distributionURL,
                modules: modules
            )
            
            // Handle OrgInfo.json if provided
            if let orgInfoURL {
                appendLog("Adding OrgInfo.json to package...")
                try await addOrgInfoToPackage(orgInfoURL: orgInfoURL, expandedFolder: expandedFolder)
            }
            
            // Flatten the PKG
            appendLog("Building final PKG...")
            try await runCommand("/usr/sbin/pkgutil", arguments: [
                "--flatten",
                expandedFolder.path,
                saveURL.path
            ])
            
            appendLog("SUCCESS - PKG created at:")
            appendLog("   \(saveURL.path)")
            if orgInfoURL != nil {
                appendLog("   (includes OrgInfo.json for Umbrella)")
            }
            appendLog("")
            appendLog("Ready for Jamf deployment!")
            
            // Open Finder at the file location
            NSWorkspace.shared.selectFile(saveURL.path, inFileViewerRootedAtPath: "")
            
        } catch {
            appendLog("[ERROR] Build error: \(error.localizedDescription)")
        }
    }
    
    /// Public method to append log (for use from ContentView)
    func appendLogPublic(_ line: String) {
        appendLog(line)
    }
    
    // MARK: - Private Helpers
    
    private func detectVersion(from dmgURL: URL) -> String? {
        let name = dmgURL.lastPathComponent
        // Look for patterns like 5.1.3.62 or 5.1.13.177
        let pattern = #"\d+\.\d+\.\d+\.\d+"#
        if let range = name.range(of: pattern, options: .regularExpression) {
            return String(name[range])
        }
        return nil
    }
    
    private func addOrgInfoToPackage(orgInfoURL: URL, expandedFolder: URL) async throws {
        let fileManager = FileManager.default
        
        guard let tempRoot else {
            throw DMGServiceError.orgInfoCreationFailed
        }
        
        // Create a temporary directory structure for the OrgInfo package
        let orgInfoPkgRoot = tempRoot.appendingPathComponent("orginfo_module.pkg")
        let payloadDir = tempRoot.appendingPathComponent("OrgInfoPayload")
        let targetDir = payloadDir.appendingPathComponent("opt/cisco/secureclient/umbrella")
        
        try fileManager.createDirectory(at: orgInfoPkgRoot, withIntermediateDirectories: true)
        try fileManager.createDirectory(at: targetDir, withIntermediateDirectories: true)
        
        // Copy OrgInfo.json to payload structure
        let destOrgInfo = targetDir.appendingPathComponent("OrgInfo.json")
        try fileManager.copyItem(at: orgInfoURL, to: destOrgInfo)
        
        // Create PackageInfo
        let packageInfo = """
        <?xml version="1.0" encoding="utf-8"?>
        <pkg-info format-version="2" identifier="com.cisco.secureclient.umbrella.orginfo" version="1.0" install-location="/" auth="root">
            <payload numberOfFiles="1"/>
        </pkg-info>
        """
        let packageInfoURL = orgInfoPkgRoot.appendingPathComponent("PackageInfo")
        try packageInfo.write(to: packageInfoURL, atomically: true, encoding: .utf8)
        
        // Create Bom from the payload directory
        let bomPath = orgInfoPkgRoot.appendingPathComponent("Bom")
        try await runCommand("/usr/bin/mkbom", arguments: [payloadDir.path, bomPath.path])
        
        // Create Payload using pax/cpio format (what pkgutil --expand creates)
        let payloadPath = orgInfoPkgRoot.appendingPathComponent("Payload")
        let cpioPath = tempRoot.appendingPathComponent("payload.cpio")
        let gzipPath = tempRoot.appendingPathComponent("payload.cpio.gz")
        
        // Create cpio archive using pax
        try await runCommandWithWorkingDir(
            "/bin/pax",
            arguments: ["-w", "-x", "cpio", "."],
            workingDirectory: payloadDir,
            outputFile: cpioPath
        )
        
        // Gzip the cpio archive
        try await runCommand("/usr/bin/gzip", arguments: ["-f", cpioPath.path])
        
        // Move to final location
        try fileManager.moveItem(at: gzipPath, to: payloadPath)
        
        // Cleanup
        try? fileManager.removeItem(at: payloadDir)
        
        // Copy the OrgInfo package component to expanded folder
        let orgInfoComponentDest = expandedFolder.appendingPathComponent("orginfo_module.pkg")
        if fileManager.fileExists(atPath: orgInfoComponentDest.path) {
            try fileManager.removeItem(at: orgInfoComponentDest)
        }
        try fileManager.copyItem(at: orgInfoPkgRoot, to: orgInfoComponentDest)
        
        // Update Distribution to include OrgInfo package
        guard let distributionURL else {
            throw DMGServiceError.orgInfoCreationFailed
        }
        
        var distributionContent = try String(contentsOf: distributionURL, encoding: .utf8)
        
        // Add pkg-ref for OrgInfo before </installer-gui-script>
        let pkgRefEntry = """
            <pkg-ref id="com.cisco.secureclient.umbrella.orginfo" version="1.0" installKBytes="1">#orginfo_module.pkg</pkg-ref>
        """
        
        // Add to choice_secure_umbrella - find the closing </choice> and add before it
        let umbrellaChoicePattern = #"(<choice\s+id="choice_secure_umbrella"[^>]*>[\s\S]*?)(</choice>)"#
        if let regex = try? NSRegularExpression(pattern: umbrellaChoicePattern, options: []) {
            let range = NSRange(location: 0, length: (distributionContent as NSString).length)
            distributionContent = regex.stringByReplacingMatches(
                in: distributionContent,
                options: [],
                range: range,
                withTemplate: "$1        <pkg-ref id=\"com.cisco.secureclient.umbrella.orginfo\"/>\n    $2"
            )
        }
        
        // Add pkg-ref definition before </installer-gui-script>
        distributionContent = distributionContent.replacingOccurrences(
            of: "</installer-gui-script>",
            with: "\(pkgRefEntry)\n</installer-gui-script>"
        )
        
        try distributionContent.write(to: distributionURL, atomically: true, encoding: .utf8)
        
        appendLog("OrgInfo.json package created and added to Distribution")
    }
    
    private func runCommand(_ launchPath: String, arguments: [String]) async throws {
        try await withCheckedThrowingContinuation { (continuation: CheckedContinuation<Void, Error>) in
            DispatchQueue.global(qos: .userInitiated).async {
                let task = Process()
                task.executableURL = URL(fileURLWithPath: launchPath)
                task.arguments = arguments
                
                let stderrPipe = Pipe()
                task.standardError = stderrPipe
                task.standardOutput = FileHandle.nullDevice
                
                do {
                    try task.run()
                    task.waitUntilExit()
                    
                    let stderrData = stderrPipe.fileHandleForReading.readDataToEndOfFile()
                    let stderr = String(data: stderrData, encoding: .utf8) ?? ""
                    
                    if task.terminationStatus != 0 {
                        let cmd = "\(launchPath) \(arguments.joined(separator: " "))"
                        continuation.resume(throwing: DMGServiceError.commandFailed(
                            command: cmd,
                            status: task.terminationStatus,
                            stderr: stderr
                        ))
                    } else {
                        continuation.resume()
                    }
                } catch {
                    continuation.resume(throwing: error)
                }
            }
        }
    }
    
    private func runCommandWithWorkingDir(_ launchPath: String, arguments: [String], workingDirectory: URL, outputFile: URL) async throws {
        try await withCheckedThrowingContinuation { (continuation: CheckedContinuation<Void, Error>) in
            DispatchQueue.global(qos: .userInitiated).async {
                let task = Process()
                task.executableURL = URL(fileURLWithPath: launchPath)
                task.arguments = arguments
                task.currentDirectoryURL = workingDirectory
                
                // Create output file if needed
                if !FileManager.default.fileExists(atPath: outputFile.path) {
                    FileManager.default.createFile(atPath: outputFile.path, contents: nil)
                }
                
                guard let outputHandle = FileHandle(forWritingAtPath: outputFile.path) else {
                    continuation.resume(throwing: DMGServiceError.orgInfoCreationFailed)
                    return
                }
                
                task.standardOutput = outputHandle
                task.standardError = FileHandle.nullDevice
                
                do {
                    try task.run()
                    task.waitUntilExit()
                    try? outputHandle.close()
                    
                    if task.terminationStatus != 0 {
                        let cmd = "\(launchPath) \(arguments.joined(separator: " "))"
                        continuation.resume(throwing: DMGServiceError.commandFailed(
                            command: cmd,
                            status: task.terminationStatus,
                            stderr: ""
                        ))
                    } else {
                        continuation.resume()
                    }
                } catch {
                    try? outputHandle.close()
                    continuation.resume(throwing: error)
                }
            }
        }
    }
    
    private func appendLog(_ line: String) {
        let timestamp = DateFormatter.localizedString(from: Date(), dateStyle: .none, timeStyle: .medium)
        logText.append("[\(timestamp)] \(line)\n")
    }
    
    private func askUserForOutputURL(suggestedName: String) async -> URL? {
        let panel = NSSavePanel()
        panel.title = "Save Repackaged PKG"
        panel.nameFieldStringValue = suggestedName
        panel.allowedContentTypes = [UTType(filenameExtension: "pkg")!]
        panel.canCreateDirectories = true
        
        let response = panel.runModal()
        return response == .OK ? panel.url : nil
    }
    
    private func cleanup() {
        // Clean up the temporary folder
        if let tempRoot {
            try? FileManager.default.removeItem(at: tempRoot)
        }
    }
    
    deinit {
        // Note: deinit is not async, so we do basic cleanup
        if let tempRoot {
            try? FileManager.default.removeItem(at: tempRoot)
        }
    }
}
