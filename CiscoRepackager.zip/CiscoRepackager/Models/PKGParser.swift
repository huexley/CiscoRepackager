//
//  PKGParser.swift
//  CiscoRepackager
//
//  Created by Yannick Housseau
//  https://github.com/huexley
//
//  MIT License - See LICENSE file for details
//

import Foundation

/// Parses and modifies the Distribution file from Cisco packages
struct PKGParser {
    
    // MARK: - Module Mapping
    
    /// Maps choice IDs to their corresponding pkg-ref IDs
    private static let choiceToPkgRef: [String: String] = [
        "choice_anyconnect_vpn": "com.cisco.pkg.anyconnect.vpn",
        "choice_dart": "com.cisco.pkg.anyconnect.dart",
        "choice_secure_firewall_posture": "com.cisco.pkg.anyconnect.posture",
        "choice_iseposture": "com.cisco.pkg.anyconnect.iseposture",
        "choice_nvm": "com.cisco.pkg.anyconnect.nvm_v2",
        "choice_secure_umbrella": "com.cisco.pkg.anyconnect.umbrella",
        "choice_thousandeyes": "com.cisco.secureclient.thousandeyes",
        "choice_duo": "com.duosecurity.duo-device-health",
        "choice_zta": "com.cisco.pkg.secureclient.zta"
    ]
    
    /// Modules that should always be included (UI module)
    private static let alwaysInclude = ["choice_ui"]
    
    /// Corresponding pkg-ref for always-included modules
    private static let alwaysIncludePkgRefs = ["com.cisco.pkg.secureclient.gui"]
    
    // MARK: - Public API
    
    /// Parses the Distribution file and extracts version + available modules
    static func parse(distributionURL: URL) throws -> CiscoPackageInfo {
        let xml = try String(contentsOf: distributionURL, encoding: .utf8)
        
        let version = extractVersion(from: xml) ?? "Unknown"
        let choiceIds = extractUserSelectableChoices(from: xml)
        
        let modules: [ModuleChoice] = choiceIds.compactMap { id in
            guard let title = extractTitle(for: id, in: xml) else { return nil }
            // By default, only VPN is selected (most common use case)
            let defaultSelected = id.contains("vpn")
            return ModuleChoice(id: id, title: title, isSelected: defaultSelected)
        }
        
        return CiscoPackageInfo(version: version, modules: modules)
    }
    
    /// Rewrites the Distribution file keeping only selected modules
    static func writeFilteredDistribution(
        originalURL: URL,
        destinationURL: URL,
        modules: [ModuleChoice]
    ) throws {
        let originalXML = try String(contentsOf: originalURL, encoding: .utf8)
        let filteredXML = filterDistribution(xml: originalXML, selectedModules: modules)
        try filteredXML.write(to: destinationURL, atomically: true, encoding: .utf8)
    }
    
    // MARK: - Parsing Helpers
    
    private static func extractVersion(from xml: String) -> String? {
        // Look for version="5.1.13.177" in pkg-ref for VPN (main module)
        let pattern = #"<pkg-ref id="com\.cisco\.pkg\.anyconnect\.vpn" version="([0-9]+\.[0-9]+\.[0-9]+\.[0-9]+)""#
        guard let regex = try? NSRegularExpression(pattern: pattern, options: []) else {
            return nil
        }
        let ns = xml as NSString
        let range = NSRange(location: 0, length: ns.length)
        if let match = regex.firstMatch(in: xml, options: [], range: range),
           match.numberOfRanges >= 2 {
            return ns.substring(with: match.range(at: 1))
        }
        return nil
    }
    
    private static func extractUserSelectableChoices(from xml: String) -> [String] {
        // Extract choice IDs from <line choice="..."/> in choices-outline
        // Exclude choice_ui which is always hidden/automatic
        let pattern = #"<line\s+choice="([^"]+)""#
        guard let regex = try? NSRegularExpression(pattern: pattern, options: []) else {
            return []
        }
        let ns = xml as NSString
        let range = NSRange(location: 0, length: ns.length)
        let matches = regex.matches(in: xml, options: [], range: range)
        
        return matches.compactMap { match in
            guard match.numberOfRanges >= 2 else { return nil }
            let choiceId = ns.substring(with: match.range(at: 1))
            // Skip UI module - it's automatic
            if choiceId == "choice_ui" { return nil }
            return choiceId
        }
    }
    
    private static func extractTitle(for choiceId: String, in xml: String) -> String? {
        // Look for <choice id="choice_xxx" ... title="Module Name" ...>
        let escapedId = NSRegularExpression.escapedPattern(for: choiceId)
        let pattern = #"<choice\s+id="\#(escapedId)"[^>]*\btitle="([^"]+)""#
        guard let regex = try? NSRegularExpression(pattern: pattern, options: []) else {
            return nil
        }
        let ns = xml as NSString
        let range = NSRange(location: 0, length: ns.length)
        if let match = regex.firstMatch(in: xml, options: [], range: range),
           match.numberOfRanges >= 2 {
            return ns.substring(with: match.range(at: 1))
        }
        return nil
    }
    
    // MARK: - Filtering
    
    private static func filterDistribution(xml: String, selectedModules: [ModuleChoice]) -> String {
        // Get the choice IDs that are selected
        let selectedChoiceIds = Set(selectedModules.filter { $0.isSelected }.map { $0.id })
        
        // Get all choice IDs to remove (not selected and not always-included)
        let allChoiceIds = Set(selectedModules.map { $0.id })
        let choicesToRemove = allChoiceIds.subtracting(selectedChoiceIds)
        
        // Get corresponding pkg-ref IDs to remove
        let pkgRefsToRemove = Set(choicesToRemove.compactMap { choiceToPkgRef[$0] })
        
        var result = xml
        
        // 1. Remove <line choice="..."/> for unselected modules
        for choiceId in choicesToRemove {
            let linePattern = #"[ \t]*<line\s+choice="\#(NSRegularExpression.escapedPattern(for: choiceId))"\s*/>\s*\n?"#
            if let regex = try? NSRegularExpression(pattern: linePattern, options: []) {
                result = regex.stringByReplacingMatches(
                    in: result,
                    options: [],
                    range: NSRange(location: 0, length: (result as NSString).length),
                    withTemplate: ""
                )
            }
        }
        
        // 2. Remove <choice id="...">...</choice> blocks for unselected modules
        for choiceId in choicesToRemove {
            let choicePattern = #"[ \t]*<choice\s+id="\#(NSRegularExpression.escapedPattern(for: choiceId))"[^>]*>[\s\S]*?</choice>\s*\n?"#
            if let regex = try? NSRegularExpression(pattern: choicePattern, options: []) {
                result = regex.stringByReplacingMatches(
                    in: result,
                    options: [],
                    range: NSRange(location: 0, length: (result as NSString).length),
                    withTemplate: ""
                )
            }
        }
        
        // 3. Remove simple <pkg-ref id="..." version="..." .../> or <pkg-ref ...>...</pkg-ref> for unselected modules
        for pkgRefId in pkgRefsToRemove {
            // Remove <pkg-ref id="...">...</pkg-ref> (with bundle-version)
            let pkgRefBlockPattern = #"[ \t]*<pkg-ref\s+id="\#(NSRegularExpression.escapedPattern(for: pkgRefId))"[^>]*>[\s\S]*?</pkg-ref>\s*\n?"#
            if let regex = try? NSRegularExpression(pattern: pkgRefBlockPattern, options: []) {
                result = regex.stringByReplacingMatches(
                    in: result,
                    options: [],
                    range: NSRange(location: 0, length: (result as NSString).length),
                    withTemplate: ""
                )
            }
            
            // Remove self-closing <pkg-ref id="..."/>
            let pkgRefSelfClosingPattern = #"[ \t]*<pkg-ref\s+id="\#(NSRegularExpression.escapedPattern(for: pkgRefId))"[^>]*/>\s*\n?"#
            if let regex = try? NSRegularExpression(pattern: pkgRefSelfClosingPattern, options: []) {
                result = regex.stringByReplacingMatches(
                    in: result,
                    options: [],
                    range: NSRange(location: 0, length: (result as NSString).length),
                    withTemplate: ""
                )
            }
        }
        
        return result
    }
}
