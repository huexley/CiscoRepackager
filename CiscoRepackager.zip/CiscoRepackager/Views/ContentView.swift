//
//  ContentView.swift
//  CiscoRepackager
//
//  Created by Yannick Housseau
//  https://github.com/huexley
//
//  MIT License - See LICENSE file for details
//

import SwiftUI
import UniformTypeIdentifiers

struct ContentView: View {
    @StateObject private var dmgService = DMGService()
    @State private var isShowingFileImporter = false
    @State private var isTargeted = false
    
    var body: some View {
        VStack(spacing: 0) {
            // Fixed header
            headerView
                .padding()
            
            Divider()
            
            // Main content based on state
            Group {
                if !dmgService.isPrepared {
                    step1DropZone
                } else {
                    step2ModuleSelection
                }
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
        }
        .frame(minWidth: 500, minHeight: 450)
        .fileImporter(
            isPresented: $isShowingFileImporter,
            allowedContentTypes: [UTType(filenameExtension: "dmg")!],
            allowsMultipleSelection: false
        ) { result in
            dmgService.handleFileImporterResult(result)
        }
    }
    
    // MARK: - Header
    
    private var headerView: some View {
        HStack {
            Image(systemName: "shippingbox.fill")
                .font(.largeTitle)
                .foregroundColor(.accentColor)
            
            VStack(alignment: .leading, spacing: 2) {
                Text("Cisco Secure Client")
                    .font(.title2)
                    .fontWeight(.bold)
                Text("Repackager for Jamf")
                    .font(.subheadline)
                    .foregroundColor(.secondary)
            }
            
            Spacer()
            
            if dmgService.isPrepared {
                Button {
                    dmgService.reset()
                } label: {
                    Label("Start Over", systemImage: "arrow.counterclockwise")
                }
                .buttonStyle(.borderless)
            }
            
            if dmgService.isBusy {
                ProgressView()
                    .scaleEffect(0.8)
                    .padding(.leading, 8)
            }
        }
    }
    
    // MARK: - Step 1: Drop Zone
    
    private var step1DropZone: some View {
        VStack(spacing: 24) {
            Spacer()
            
            // Drop zone
            VStack(spacing: 16) {
                ZStack {
                    RoundedRectangle(cornerRadius: 16)
                        .strokeBorder(
                            isTargeted ? Color.accentColor : Color.gray.opacity(0.3),
                            style: StrokeStyle(lineWidth: 2, dash: [10])
                        )
                        .background(
                            RoundedRectangle(cornerRadius: 16)
                                .fill(isTargeted ? Color.accentColor.opacity(0.08) : Color.gray.opacity(0.03))
                        )
                    
                    VStack(spacing: 12) {
                        Image(systemName: "opticaldisc")
                            .font(.system(size: 48))
                            .foregroundColor(isTargeted ? .accentColor : .secondary)
                        
                        Text("Drop Cisco Secure Client DMG here")
                            .font(.headline)
                            .foregroundColor(.primary)
                        
                        Text("or click to browse")
                            .font(.subheadline)
                            .foregroundColor(.secondary)
                    }
                }
                .frame(height: 200)
                .contentShape(Rectangle())
                .onTapGesture {
                    isShowingFileImporter = true
                }
                .onDrop(of: [.fileURL], isTargeted: $isTargeted) { providers in
                    dmgService.handleDrop(providers: providers)
                }
                .animation(.easeInOut(duration: 0.2), value: isTargeted)
            }
            .padding(.horizontal, 40)
            
            // Info when DMG is selected
            if let dmgURL = dmgService.dmgURL {
                VStack(spacing: 12) {
                    HStack(spacing: 8) {
                        Image(systemName: "checkmark.circle.fill")
                            .foregroundColor(.green)
                        Text(dmgURL.lastPathComponent)
                            .fontWeight(.medium)
                        if let version = dmgService.version {
                            Text("v\(version)")
                                .foregroundColor(.secondary)
                                .padding(.horizontal, 8)
                                .padding(.vertical, 2)
                                .background(Color.secondary.opacity(0.15))
                                .clipShape(Capsule())
                        }
                    }
                    
                    Button {
                        Task { await dmgService.prepare() }
                    } label: {
                        HStack {
                            Image(systemName: "arrow.right.circle.fill")
                            Text("Continue")
                        }
                        .frame(minWidth: 120)
                    }
                    .buttonStyle(.borderedProminent)
                    .controlSize(.large)
                    .disabled(dmgService.isBusy)
                }
            }
            
            // Discreet log at the bottom
            if !dmgService.logText.isEmpty {
                logView
                    .frame(height: 80)
                    .padding(.horizontal)
            }
            
            Spacer()
        }
    }
    
    // MARK: - Step 2: Module Selection
    
    private var step2ModuleSelection: some View {
        VStack(spacing: 0) {
            // DMG info bar
            HStack {
                Image(systemName: "opticaldisc.fill")
                    .foregroundColor(.accentColor)
                if let dmgURL = dmgService.dmgURL {
                    Text(dmgURL.lastPathComponent)
                        .fontWeight(.medium)
                }
                if let version = dmgService.version {
                    Text("v\(version)")
                        .foregroundColor(.secondary)
                        .padding(.horizontal, 8)
                        .padding(.vertical, 2)
                        .background(Color.secondary.opacity(0.15))
                        .clipShape(Capsule())
                }
                Spacer()
                
                Button("Select All") {
                    for i in dmgService.modules.indices {
                        dmgService.modules[i].isSelected = true
                    }
                }
                .buttonStyle(.borderless)
                
                Button("None") {
                    for i in dmgService.modules.indices {
                        dmgService.modules[i].isSelected = false
                    }
                }
                .buttonStyle(.borderless)
            }
            .padding()
            .background(Color.gray.opacity(0.05))
            
            Divider()
            
            // Module list
            ScrollView {
                VStack(alignment: .leading, spacing: 0) {
                    ForEach($dmgService.modules) { $module in
                        ModuleRow(module: $module)
                        
                        if module.id != dmgService.modules.last?.id {
                            Divider()
                                .padding(.leading, 52)
                        }
                    }
                }
            }
            
            Divider()
            
            // Log
            logView
                .frame(height: 100)
            
            Divider()
            
            // Build button
            HStack {
                if !dmgService.hasSelectedModules {
                    HStack(spacing: 4) {
                        Image(systemName: "exclamationmark.triangle.fill")
                            .foregroundColor(.orange)
                        Text("Select at least one module")
                            .foregroundColor(.secondary)
                    }
                }
                
                Spacer()
                
                Button {
                    Task { await dmgService.buildFinalPKG() }
                } label: {
                    HStack {
                        Image(systemName: "hammer.fill")
                        Text("Build PKG")
                    }
                    .frame(minWidth: 140)
                }
                .buttonStyle(.borderedProminent)
                .tint(.green)
                .controlSize(.large)
                .disabled(!dmgService.hasSelectedModules || dmgService.isBusy)
            }
            .padding()
        }
    }
    
    // MARK: - Log View
    
    private var logView: some View {
        ScrollViewReader { proxy in
            ScrollView {
                Text(dmgService.logText.isEmpty ? "Ready..." : dmgService.logText)
                    .font(.system(size: 11, design: .monospaced))
                    .foregroundColor(dmgService.logText.isEmpty ? .secondary : .primary)
                    .frame(maxWidth: .infinity, alignment: .topLeading)
                    .padding(8)
                    .id("logBottom")
            }
            .background(Color(NSColor.textBackgroundColor))
            .onChange(of: dmgService.logText) { _, _ in
                withAnimation {
                    proxy.scrollTo("logBottom", anchor: .bottom)
                }
            }
        }
    }
}

// MARK: - Module Row

struct ModuleRow: View {
    @Binding var module: ModuleChoice
    
    var body: some View {
        HStack(spacing: 12) {
            Toggle("", isOn: $module.isSelected)
                .toggleStyle(.checkbox)
                .labelsHidden()
            
            moduleIcon
                .font(.title2)
                .foregroundColor(module.isSelected ? .accentColor : .secondary)
                .frame(width: 28)
            
            VStack(alignment: .leading, spacing: 2) {
                Text(module.title)
                    .fontWeight(.medium)
                    .foregroundColor(module.isSelected ? .primary : .secondary)
                
                Text(moduleDescription)
                    .font(.caption)
                    .foregroundColor(.secondary)
            }
            
            Spacer()
        }
        .padding(.horizontal)
        .padding(.vertical, 10)
        .contentShape(Rectangle())
        .onTapGesture {
            module.isSelected.toggle()
        }
    }
    
    private var moduleIcon: Image {
        let id = module.id.lowercased()
        if id.contains("vpn") {
            return Image(systemName: "lock.shield.fill")
        } else if id.contains("fireamp") || id.contains("amp") {
            return Image(systemName: "shield.checkered")
        } else if id.contains("dart") {
            return Image(systemName: "wrench.and.screwdriver.fill")
        } else if id.contains("posture") || id.contains("ise") {
            return Image(systemName: "checkmark.seal.fill")
        } else if id.contains("nvm") {
            return Image(systemName: "eye.fill")
        } else if id.contains("umbrella") {
            return Image(systemName: "umbrella.fill")
        } else if id.contains("duo") {
            return Image(systemName: "person.2.fill")
        } else if id.contains("zta") || id.contains("ztna") {
            return Image(systemName: "network.badge.shield.half.filled")
        } else if id.contains("thousandeyes") {
            return Image(systemName: "waveform.path.ecg")
        } else {
            return Image(systemName: "puzzlepiece.fill")
        }
    }
    
    private var moduleDescription: String {
        let id = module.id.lowercased()
        if id.contains("vpn") {
            return "Secure VPN client for remote access"
        } else if id.contains("fireamp") || id.contains("amp") {
            return "Advanced Malware Protection"
        } else if id.contains("dart") {
            return "Diagnostic and Reporting Tool"
        } else if id.contains("posture") || id.contains("ise") {
            return "Endpoint compliance assessment"
        } else if id.contains("nvm") {
            return "Network Visibility Module"
        } else if id.contains("umbrella") {
            return "DNS-layer security"
        } else if id.contains("duo") {
            return "Multi-factor authentication"
        } else if id.contains("zta") || id.contains("ztna") {
            return "Zero Trust Access"
        } else if id.contains("thousandeyes") {
            return "Network intelligence"
        } else {
            return "Cisco security module"
        }
    }
}

// MARK: - Preview

#Preview {
    ContentView()
}
